# About
This is a plugin for Endless Sky, created by Lemuria. It adds a new commodity called "Data drives" which you can transport around the galaxy in the form of missions. Also, extra star systems cause why not?

Disclaimer: May contain mild traces of the Hai ambassador "Sayari".

Ingredients: VS Code, Endless Sky, Lemuria's brain cells, electricity, mac, sweat, hardwork, MSG, plugins, GitHub, copyrights, credits, coding experience, natural flavors, Sayari photos, Sayari, immersive simulations of Sayari, wizards, Kar Ik Vot 349s, Bactrians, Bactrains, Leviathans, Yuyuko, cheese, data drives, food, luxury goods, industrial, electronics, missions, failed missions, free worlds, actual Free Worlds, humans, Hai, Korath, Korath Raiders, Korath World Ships, Syndicate Bulk Freighters, Clippers, frogs, ants, terraformers, hyperdrives, jump drives, heat shunts and more.
# Changelog 

## v0.1
 First version of the plugin.


# Content Rating
Dialogue and "strings" visible to players do not contain mild/major swear words, not even their substitutes. This add-on has not been assigned any official ratings by rating agencies such as the ESRB, PEGI, or your country's video game rating authority.

Do note that this addon has references to slavery and organized crime (pirates).

# Copyrights
Plugin copyright: Copyright (C) Lemuria#0685 2021. License: GPLv3, view in LICENSE.md
Contact:          Lemuria#0685 (Discord)


Can't find the attribution for your image? Use the search feature of your code editor or whatever program you're using to read this.

To make it easier to contact the author, you may join the Endless Sky discord server at:
                  X####################################X
                  | https://discord.com/invite/ZeuASSx |
                  X####################################X


 - Laateli landscape image, Themanilaxperience, CC BY-SA 3.0
   https://commons.wikimedia.org/wiki/File:Makatiskyline.jpg

 - Leroo Station landscape image, Bill Ebbesen, CC BY 3.0
   https://commons.wikimedia.org/wiki/File:Heatpipe_tunnel_copenhagen_2009.jpg

 - Markaii landscape image, Aleksandar Pasaric, Downloaded from pexels.com
   https://www.pexels.com/photo/concrete-high-rise-buildings-under-blue-sky-618079/?utm_content=attributionCopyText&utm_medium=referral&utm_source=pexels
 -
  
 -
  
 -
  
 -
  
 -
